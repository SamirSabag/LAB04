/*
 * PWM.h
 *
 *  Created on: Feb 27, 2018
 *      Author: samir
 */

#ifndef PWM_H_
#define PWM_H_

void TPM_Handler(void);
void TPM_Init(void);


#endif /* PWM_H_ */
